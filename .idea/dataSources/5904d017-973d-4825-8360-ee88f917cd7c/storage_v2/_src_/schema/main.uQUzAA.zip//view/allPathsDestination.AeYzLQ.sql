CREATE VIEW allPathsDestination as
	select
	       dest_fold_id,
	       dest_fold_name,
	       dest_fold_path 
	from destination_folder;

