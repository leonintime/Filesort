CREATE VIEW getConnectedFolders as
select distinct moving_files_folder.mff_name, moving_files_folder.mff_path, dest_fold_name, moving_files_folder.mff_id,  dest_fold_path
from file_moving,
     destination_folder,
     file_extensions,
     moving_files_folder

WHERE file_moving.dest_folder_id = destination_folder.dest_fold_id
  AND file_moving.mff_id = moving_files_folder.mff_id;

